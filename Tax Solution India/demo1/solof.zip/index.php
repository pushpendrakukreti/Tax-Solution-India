<?php

$name=$_POST['Name'];
$number=$_POST['Phone'];
echo "your name is $name and ur number is $number";






?>